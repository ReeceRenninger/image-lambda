'use strict';
import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { Response } from node-fetch;

// const AWS = require('aws-sdk');
const s3Client = new S3Client({region: "us-west-1"});
const GetObjectCommand = GetObjectCommand();
const PutObjectCommand = PutObjectCommand();

export const handler = async (event) => {
  // TODO implement
  let name = event.Records[0].s3.object.key;
  let size = event.Records[0].s3.object.size;
  let type = 'jpg';
  let newImageObject = { name, size, type };
  console.log(newImageObject);

  let images = []; // may override so this may need to be after console.log error

  let params = {
    Bucket: 'reece-images',
    Key: 'images.json',
  };
  // grab all objects in the bucket
  try {
    let s3results = await s3Client.send(new GetObjectCommand(params));
    const images = new Response (s3results.Body);
    console.log(images);
    // images = JSON.parse(data.Body.toString()); //does this need to be Body like the demo?
    // console.log(images);
  } catch (error) {
    console.log('error: ', error);
    
  }

  images.push(newImageObject);
  params.Body = JSON.stringify(images);

  // modify or create a new object in the bucket
  // let newParams = {
  //   ...params,
  //   Key: 'images.json',
  //   Body: <updatedSummaryJSon>,
  //   ContentType: "application/json"
  // }

  try {
    await s3Client.PutObjectCommand(params).promise();
  } catch (error) {
    console.log('error: ', error);
    
  }

  const response = {
    statusCode: 200,
    body: JSON.stringify(images),
  };
  return response;
};
